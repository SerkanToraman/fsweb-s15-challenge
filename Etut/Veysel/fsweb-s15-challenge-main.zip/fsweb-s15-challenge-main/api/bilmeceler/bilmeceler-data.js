// Değişiklik yapmayın
const bilmeceler = [
  {
    "id": "123Dh34TyTn",
    "bilmece": "Bir kamyonu kim tek eliyle durdurabilir?"
  },
  {
    "id": "34EE0543eSk",
    "bilmece": "Yürür iz etmez, hızlansa toz etmez"
  },
  {
    "id": "Mlt54Tm598l",
    "bilmece": "Dört ayağı olsa da adım atamaz"
  },
];

module.exports = bilmeceler;
